package com.exam.andex.andex01_hello;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by Administrator on 2016-07-05.
 */
public class Hello3Activity extends Activity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.hello3main);
    }
}
